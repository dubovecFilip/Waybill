'use strict';

/**
 * Console formatting for job lifecycle events, shared by replay.js (offline)
 * and live.js (tailing a session while it's being recorded) so the two never
 * drift apart.
 */

function printJobStarted(job) {
  console.log(
    `\n>> ZACIATOK  ${job.sourceCity} (${job.sourceCompany})  ->  ${job.destinationCity} (${job.destinationCompany})`
  );
  console.log(
    `   naklad: ${job.cargo}, ${Math.round(job.cargoMassKg)} kg, plan ${job.plannedDistanceKm} km, ponuka ${job.income}`
  );
}

function printJobFinished(r) {
  console.log(`\n<< KONIEC  vysledok: ${r.outcome}`);
  console.log(`   trasa: ${r.source.city} -> ${r.destination.city}`);
  console.log(`   moje km: ${r.distanceKm}`);
  if (typeof r.reportedDistanceKm === 'number') {
    const diff = r.reportedDistanceKm > 0 ? ((r.distanceKm / r.reportedDistanceKm - 1) * 100).toFixed(1) : '?';
    console.log(`   hra hlasi km: ${r.reportedDistanceKm}  (rozdiel ${diff} %)`);
  }
  console.log(`   realna trasa na mape: ${r.worldDistanceKm} km (mapa je zmensena)`);
  if (typeof r.revenue === 'number') console.log(`   vyplatene: ${r.revenue} (ponuka bola ${r.offeredIncome})`);
  console.log(`   palivo: ${r.fuelUsedL} l, priemer ${r.avgConsumptionLper100} l/100km`);
  console.log(`   maximalka: ${r.topSpeedKmh} km/h, prekracovanie ${(r.speedingShare * 100).toFixed(1)} % casu`);
  console.log(`   poskodenie: kamion ${(r.truckDamage * 100).toFixed(2)} %, naves ${(r.trailerDamage * 100).toFixed(2)} %`);
  if (r.collisions) console.log(`   kolizie: ${r.collisions}x`);
  if (r.lateDelivery) console.log(`   MESKANIE: ${Math.round(r.minutesLate)} hernych minut po termine`);
  if (r.fines.length) {
    const total = r.fines.reduce((a, f) => a + (f.amount || 0), 0);
    console.log(`   pokuty: ${r.fines.length}x, spolu ${total}`);
  }
  console.log(`   verdikt: ${r.validation.status}${r.validation.flags.length ? ' [' + r.validation.flags.join(', ') + ']' : ''}`);
}

module.exports = { printJobStarted, printJobFinished };
