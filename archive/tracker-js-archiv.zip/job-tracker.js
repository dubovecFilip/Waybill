'use strict';

/**
 * Job tracker core for ETS2 and ATS.
 *
 * This module is deliberately free of any IO. You feed it normalised snapshots
 * of telemetry and it emits job lifecycle events. That makes it testable with
 * recorded telemetry files, which you will want once people start disputing
 * their logged jobs.
 *
 * Expected snapshot shape (see normaliseExample at the bottom of the file):
 *
 * {
 *   connected: boolean,
 *   paused: boolean,
 *   game: 'ETS2' | 'ATS',
 *   gameVersion: string,
 *   gameTimeMin: number,          // in game minutes, monotonic
 *   onJob: boolean,
 *   job: {
 *     sourceCity, sourceCompany, destinationCity, destinationCompany,
 *     cargo, cargoMassKg, income, deadlineMin, plannedDistanceKm
 *   } | null,
 *   truck: {
 *     make, model, odometerKm, speedKmh, fuelL, fuelCapacityL,
 *     wear: { engine, transmission, cabin, chassis, wheels }  // 0 to 1
 *   },
 *   trailer: { attached, name, wear },
 *   position: { x, y, z },        // world metres
 *   speedLimitKmh: number,        // 0 when unknown
 *   events: {                     // one shot flags from the SDK, cleared each tick
 *     jobDelivered: { revenue, earnedXp, cargoDamage, distanceKm, deliveryTimeMin, autoparkUsed } | null,
 *     jobCancelled: { penalty } | null,
 *     fined: { offence, amount } | null,
 *     tollgatePaid: { amount } | null,
 *     ferryUsed: { source, target, price } | null,
 *     trainUsed: { source, target, price } | null,
 *     refuelPaid: { amount } | null
 *   }
 * }
 */

const DEFAULT_CONFIG = {
  // Anything faster than this between two ticks is treated as a teleport.
  teleportSpeedKmh: 400,
  // The odometer counts simulated km at the game's compressed time rate, so at
  // highway speed a single ~1s poll legitimately advances it by ~0.4-0.7 km.
  // This cap sits well above that: it catches gross manipulation, not driving.
  maxOdometerJumpKm: 5.0,
  odometerSlackKm: 0.05,
  // Game time advances ~13x real time, in whole-minute steps. A tick covering
  // more than this means the clock jumped (sleep, ferry, teleport) rather than
  // time simply passing, so it is left out of the speed integral.
  maxTickGameMinutes: 5.0,
  // Ordinary driving wears the truck by ~0.0006% per tick, very consistently. An
  // impact is orders of magnitude above that, so 0.1% in a single tick separates
  // the two with a lot of room to spare.
  collisionDamageStep: 0.001,
  // Below this the tick is ignored entirely, protects against duplicate polls.
  minTickMs: 100,
  // Above this a gap is treated as a client freeze or a reconnect.
  maxTickMs: 10000,
  // The SDK's odometer field has been observed to report burst jumps of up to
  // ~0.4 km in one tick with no corresponding movement in world position, so
  // it is only cross-checked against position-derived distance, not trusted
  // on its own. Anything under this is normal odometer noise.
  odometerMismatchKm: 0.5,
  // A Quick Job swaps the player into a company truck and teleports them to
  // the pickup point, but the odometer/position fields lag a few ticks
  // behind the truck identity change before they settle on the new truck's
  // real values. Teleport/odometer checks are softened for this long after
  // a job starts so that settle-in isn't mistaken for cheating.
  jobStartGraceMs: 15000,
  // How much over the posted limit counts as speeding.
  speedingToleranceKmh: 5,
  // A job shorter than this is almost certainly a bug or an abuse attempt.
  minPlausibleDistanceKm: 0.5,
  // The SDK is known to clear JobValues/OnJob on the tick BEFORE actually firing
  // JobCancelled (observed 19ms apart in a real recording - a slow poll cycle
  // could stretch that further), so closing the job the instant its data
  // disappears means the real completion event arrives one tick later to find
  // `current` already cleared and gets silently dropped - a clean cancellation
  // turns into a falsely-rejected "unresolved" job. Wait this long for the real
  // event before giving up and closing it as unresolved for real.
  missingJobGraceMs: 3000,
};

const STATE = {
  IDLE: 'IDLE',
  ACCEPTED: 'ACCEPTED',
  DRIVING: 'DRIVING',
};

function fingerprint(job) {
  if (!job) return null;
  return [
    job.sourceCity,
    job.sourceCompany,
    job.destinationCity,
    job.destinationCompany,
    job.cargo,
    job.income,
    job.deadlineMin,
  ].join('|');
}

function distanceM(a, b) {
  if (!a || !b) return 0;
  const dx = a.x - b.x;
  const dy = a.y - b.y;
  const dz = a.z - b.z;
  return Math.sqrt(dx * dx + dy * dy + dz * dz);
}

function totalWear(wear) {
  if (!wear) return 0;
  const parts = [wear.engine, wear.transmission, wear.cabin, wear.chassis, wear.wheels];
  const valid = parts.filter((v) => typeof v === 'number');
  if (!valid.length) return 0;
  return valid.reduce((a, b) => a + b, 0) / valid.length;
}

class JobTracker {
  constructor(config = {}) {
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.state = STATE.IDLE;
    this.current = null;
    this.prev = null;
    this.prevAt = null;
  }

  /**
   * Feed one telemetry snapshot.
   * Returns an array of events, each of the form { type, ... }.
   * Types: job_started, job_finished, anomaly.
   */
  update(snap, nowMs = Date.now()) {
    const out = [];

    if (!snap || !snap.connected) {
      this.prev = null;
      this.prevAt = null;
      return out;
    }

    const prev = this.prev;
    const prevAt = this.prevAt;
    this.prev = snap;
    this.prevAt = nowMs;

    // First tick after a connect has nothing to compare against.
    if (!prev || prevAt === null) return out;

    const dtMs = nowMs - prevAt;
    const hasEnd = snap.events && (snap.events.jobDelivered || snap.events.jobCancelled);
	if (dtMs < this.config.minTickMs && !hasEnd) return out;

    const gap = dtMs > this.config.maxTickMs;
    const fp = fingerprint(snap.job);

    // A finished job wins over everything else this tick.
    const delivered = snap.events && snap.events.jobDelivered;
    const cancelled = snap.events && snap.events.jobCancelled;

    if (this.current && (delivered || cancelled)) {
      this._accumulate(snap, prev, dtMs, gap, nowMs);
      const record = this._close(snap, delivered ? 'delivered' : 'cancelled', delivered || cancelled, nowMs);
      out.push({ type: 'job_finished', record });
      this.state = STATE.IDLE;
      this.current = null;
      return out;
    }

    // New job accepted.
    if (fp && fp !== (this.current && this.current.fingerprint)) {
      if (this.current) {
        // The old job vanished without an event. Close it as unresolved and flag it.
        const record = this._close(prev, 'unresolved', null, nowMs);
        out.push({ type: 'job_finished', record });
      }
      this._open(snap, fp, nowMs);
      this.state = STATE.ACCEPTED;
      out.push({ type: 'job_started', job: { ...this.current.job }, startedAt: this.current.startedAt });
      return out;
    }

    // Job data disappeared. Give the real completion event a short window to
    // show up (see missingJobGraceMs) before writing this off as unresolved.
    if (!fp && this.current) {
      if (this.current.missingJobSinceMs == null) this.current.missingJobSinceMs = nowMs;
      if (nowMs - this.current.missingJobSinceMs < this.config.missingJobGraceMs) {
        return out;
      }
      const record = this._close(prev, 'unresolved', null, nowMs);
      out.push({ type: 'job_finished', record });
      this.state = STATE.IDLE;
      this.current = null;
      return out;
    }

    if (!this.current) return out;

    this.current.missingJobSinceMs = null;
    const anomalies = this._accumulate(snap, prev, dtMs, gap, nowMs);
    for (const a of anomalies) out.push({ type: 'anomaly', ...a });

    if (this.state === STATE.ACCEPTED && this.current.distanceKm > 0.05) {
      this.state = STATE.DRIVING;
    }

    return out;
  }

  _open(snap, fp, nowMs) {
    this.current = {
      fingerprint: fp,
      startedAt: nowMs,
      startedAtGameMin: snap.gameTimeMin,
      game: snap.game,
      gameVersion: snap.gameVersion,
      job: { ...snap.job },
      truck: { make: snap.truck.make, model: snap.truck.model },
      trailerName: snap.trailer ? snap.trailer.name : null,
      startOdometerKm: snap.truck.odometerKm,
      startFuelL: snap.truck.fuelL,
      startTruckWear: totalWear(snap.truck.wear),
      startTrailerWear: snap.trailer ? snap.trailer.wear : 0,
      distanceKm: 0,
      worldDistanceKm: 0,
      simSpeedDistanceKm: 0,
      fuelUsedL: 0,
      drivingMs: 0,
      pausedMs: 0,
      speedingMs: 0,
      topSpeedKmh: 0,
      fines: [],
      tolls: 0,
      ferries: 0,
      refuels: 0,
      collisions: 0,
      anomalies: [],
    };
  }

  _accumulate(snap, prev, dtMs, gap, nowMs) {
    const j = this.current;
    const found = [];

    if (snap.paused) {
      j.pausedMs += dtMs;
      return found;
    }

    // The SDK reports an odometer of exactly 0, with position frozen at a
    // placeholder, while the truck has not yet spawned into the world (e.g.
    // right after accepting a job, during the loading screen). The tick where
    // real telemetry first appears then looks like a multi-hundred-km/h
    // teleport. Treat that one-time transition as a warmup, not movement.
    if (prev.truck.odometerKm === 0 || snap.truck.odometerKm === 0) {
      found.push({ code: 'telemetry_warmup' });
      for (const a of found) j.anomalies.push({ at: Date.now(), ...a });
      return found;
    }

    // A Quick Job swaps the player into a company-owned truck for the
    // duration of the job (own truck -> job truck), teleporting them to the
    // pickup point and auto-filling the new truck's tank. That produces a
    // huge position/odometer/fuel jump on the tick where the truck identity
    // changes, none of which is real driving or a paid refuel.
    if (snap.truck.make !== prev.truck.make || snap.truck.model !== prev.truck.model) {
      found.push({
        code: 'vehicle_swap',
        from: `${prev.truck.make} ${prev.truck.model}`,
        to: `${snap.truck.make} ${snap.truck.model}`,
      });
      j.truck = { make: snap.truck.make, model: snap.truck.model };
      j.startFuelL = snap.truck.fuelL;
      j.startTruckWear = totalWear(snap.truck.wear);
      for (const a of found) j.anomalies.push({ at: Date.now(), ...a });
      return found;
    }

    // Odometer/position can still take a few extra ticks to settle onto the
    // new truck's real values after a Quick Job swap (see vehicle_swap
    // above), so teleport/odometer checks stay soft for a short grace period
    // after the job starts.
    const inGrace = nowMs - j.startedAt < this.config.jobStartGraceMs;

    // Two different units are in play and they must never be mixed:
    //
    //   * The odometer, the speedometer, the job's planned distance, the payout
    //     and the delivery screen are all in the game's "simulated km".
    //   * World-space position is in real map metres, and the map is compressed
    //     (~13.5x on the routes measured here), so it yields a much smaller number.
    //
    // Both are internally consistent - measured on one real drive: odometer
    // 176.60 km and speed x game-time 175.62 km (game reported 176), versus
    // position 13.08 km and speed x real-time 12.94 km. Distance reported for a
    // delivery is the simulated one, so the odometer leads and position is kept
    // separately for teleport detection and future route/map work.
    const movedKm = distanceM(snap.position, prev.position) / 1000;
    const impliedKmh = movedKm / (dtMs / 3600000);
    const teleported = !gap && impliedKmh > this.config.teleportSpeedKmh;

    if (teleported) {
      found.push({
        code: inGrace ? 'job_start_transition' : 'teleport',
        impliedKmh: Math.round(impliedKmh),
        movedKm,
      });
    } else {
      j.worldDistanceKm += movedKm;
    }

    const odoDelta = snap.truck.odometerKm - prev.truck.odometerKm;
    if (odoDelta < -this.config.odometerSlackKm) {
      found.push({ code: 'odometer_reverse', delta: odoDelta });
    } else if (odoDelta > this.config.maxOdometerJumpKm) {
      // Never counted as distance either way - a jump this size is a different
      // truck's odometer, not driving. But it is only *evidence* of anything when
      // it can't be explained: the reading settles onto the assigned truck's own
      // odometer a few ticks AFTER make/model already changed (jumps of 50k-840k km
      // observed, all just after job start), and a polling gap also leaves a
      // legitimately large step behind.
      found.push({
        code: inGrace || gap ? 'odometer_settle' : 'odometer_jump',
        delta: odoDelta,
        allowed: this.config.maxOdometerJumpKm,
      });
    } else if (!teleported && odoDelta > 0) {
      j.distanceKm += odoDelta;
    }

    // Independent second opinion on the same simulated km, for the cross-check in
    // validate(). Game time only has 1-minute resolution, so per tick this is
    // mostly zero and only meaningful once summed over a whole job.
    const dtGameHours = (snap.gameTimeMin - prev.gameTimeMin) / 60;
    if (!gap && dtGameHours > 0 && dtGameHours < this.config.maxTickGameMinutes / 60) {
      j.simSpeedDistanceKm += snap.truck.speedKmh * dtGameHours;
    }

    // A sudden damage step is an impact. Recorded as metadata for safety stats
    // (see project_vision) - it never invalidates a delivery, it just gets counted
    // and shown. Warmup and vehicle swaps return earlier, so the big artificial
    // damage steps those cause never reach this.
    const truckDamageStep = totalWear(snap.truck.wear) - totalWear(prev.truck.wear);
    const trailerDamageStep = (snap.trailer ? snap.trailer.wear : 0) - (prev.trailer ? prev.trailer.wear : 0);
    const damageStep = Math.max(truckDamageStep, trailerDamageStep);
    if (damageStep > this.config.collisionDamageStep) {
      j.collisions += 1;
      found.push({ code: 'collision', delta: damageStep });
    }

    // Fuel. An increase means a refuel, not negative consumption.
    const fuelDelta = prev.truck.fuelL - snap.truck.fuelL;
    if (fuelDelta > 0) j.fuelUsedL += fuelDelta;

    j.drivingMs += dtMs;
    if (snap.truck.speedKmh > j.topSpeedKmh) j.topSpeedKmh = snap.truck.speedKmh;

    if (
      snap.speedLimitKmh > 0 &&
      snap.truck.speedKmh > snap.speedLimitKmh + this.config.speedingToleranceKmh
    ) {
      j.speedingMs += dtMs;
    }

    const e = snap.events || {};
    if (e.fined) j.fines.push({ ...e.fined });
    if (e.tollgatePaid) j.tolls += e.tollgatePaid.amount || 0;
    if (e.ferryUsed) j.ferries += 1;
    if (e.trainUsed) j.ferries += 1;
    if (e.refuelPaid) {
      if (inGrace) {
        // A Quick Job auto-fills the assigned truck's tank as part of the swap
        // (see vehicle_swap above) and fires refuelPaid for it a few ticks later,
        // well inside the job-start grace window - the player never touched a
        // pump. Log it for debugging, but don't count it as a player refuel.
        found.push({ code: 'system_refuel', delta: e.refuelPaid.amount });
      } else {
        j.refuels += 1;
      }
    }

    if (gap) found.push({ code: 'client_gap', dtMs });

    for (const a of found) j.anomalies.push({ at: Date.now(), ...a });
    return found;
  }

  _close(snap, outcome, payload, nowMs) {
    const j = this.current;
    const record = {
      outcome,
      game: j.game,
      gameVersion: j.gameVersion,
      startedAt: j.startedAt,
      finishedAt: nowMs,
      realDurationMs: nowMs - j.startedAt,
      gameDurationMin: snap.gameTimeMin - j.startedAtGameMin,
      source: { city: j.job.sourceCity, company: j.job.sourceCompany },
      destination: { city: j.job.destinationCity, company: j.job.destinationCompany },
      cargo: j.job.cargo,
      cargoMassKg: j.job.cargoMassKg,
      plannedDistanceKm: j.job.plannedDistanceKm,
      offeredIncome: j.job.income,
      truck: j.truck,
      trailerName: j.trailerName,
      distanceKm: round(j.distanceKm, 3),
      worldDistanceKm: round(j.worldDistanceKm, 3),
      simSpeedDistanceKm: round(j.simSpeedDistanceKm, 3),
      fuelUsedL: round(j.fuelUsedL, 2),
      avgConsumptionLper100: j.distanceKm > 0.1 ? round((j.fuelUsedL / j.distanceKm) * 100, 2) : null,
      topSpeedKmh: round(j.topSpeedKmh, 1),
      drivingMs: j.drivingMs,
      pausedMs: j.pausedMs,
      speedingShare: j.drivingMs > 0 ? round(j.speedingMs / j.drivingMs, 4) : 0,
      truckDamage: round(totalWear(snap.truck.wear) - j.startTruckWear, 4),
      trailerDamage: round((snap.trailer ? snap.trailer.wear : 0) - j.startTrailerWear, 4),
      fines: j.fines,
      tollsPaid: j.tolls,
      ferriesUsed: j.ferries,
      refuels: j.refuels,
      collisions: j.collisions,
      anomalies: j.anomalies,
    };

    // job.deadlineMin is the absolute in-game minute the delivery window closes,
    // so comparing it against the clock at finish gives the lateness the game
    // itself already charged for. Statistics only - never a rejection.
    if (j.job.deadlineMin > 0 && snap.gameTimeMin > 0) {
      record.minutesLate = round(snap.gameTimeMin - j.job.deadlineMin, 1);
      record.lateDelivery = record.minutesLate > 0;
    }

    if (outcome === 'delivered' && payload) {
      record.revenue = payload.revenue;
      record.cargoDamage = payload.cargoDamage;
      record.autoparkUsed = !!payload.autoparkUsed;
      record.reportedDistanceKm = payload.distanceKm;
      record.deliveryTimeMin = payload.deliveryTimeMin;
    }
    if (outcome === 'cancelled' && payload) {
      record.penalty = payload.penalty;
    }

    record.validation = validate(record, this.config);
    return record;
  }
}

/**
 * Turns the raw anomaly list into a verdict the backend can act on.
 * Keep the raw flags in the record so a manager can review a rejection later.
 */
function validate(record, config = DEFAULT_CONFIG) {
  const flags = [];

  if (record.outcome === 'unresolved') flags.push('no_completion_event');
  if (record.distanceKm < config.minPlausibleDistanceKm) flags.push('distance_too_short');

  const teleports = record.anomalies.filter((a) => a.code === 'teleport').length;
  const odometerJumps = record.anomalies.filter((a) => a.code === 'odometer_jump').length;
  const gaps = record.anomalies.filter((a) => a.code === 'client_gap').length;

  if (teleports > 0) flags.push('teleport_detected');
  if (odometerJumps > 0) flags.push('odometer_manipulation');
  if (gaps > 2) flags.push('unstable_client');
  if (record.topSpeedKmh > 180) flags.push('implausible_top_speed');

  // Cross-check the odometer against speed integrated over game time. Both are in
  // simulated km and come from different fields, so faking one means keeping the
  // other consistent with it. On a clean recorded drive these landed within 0.6%
  // of each other (176.60 vs 175.62 km). Only meaningful once the job is long
  // enough that game time's 1-minute resolution stops dominating.
  if (record.distanceKm > 5 && record.simSpeedDistanceKm > 0) {
    const ratio = record.distanceKm / record.simSpeedDistanceKm;
    if (ratio < 0.75 || ratio > 1.33) flags.push('distance_inconsistent');
  }

  // The game reports its own distance on delivery, in the same simulated km the
  // odometer counts, so this is a like-for-like comparison and a genuinely strong
  // signal: skipping the drive can't produce a matching odometer delta.
  if (typeof record.reportedDistanceKm === 'number' && record.reportedDistanceKm > 0 && record.distanceKm > 0) {
    const ratio = record.distanceKm / record.reportedDistanceKm;
    if (ratio < 0.8 || ratio > 1.25) flags.push('distance_mismatch');
  }

  const hard = ['teleport_detected', 'no_completion_event', 'distance_too_short', 'odometer_manipulation'];
  const rejected = flags.some((f) => hard.includes(f));

  return {
    flags,
    status: rejected ? 'rejected' : flags.length ? 'review' : 'accepted',
  };
}

function round(v, digits) {
  const f = Math.pow(10, digits);
  return Math.round(v * f) / f;
}

module.exports = { JobTracker, validate, fingerprint, STATE, DEFAULT_CONFIG };
