'use strict';

/**
 * Maps a raw SCSSdkClient telemetry object (the "d" field of a recorder line)
 * onto the snapshot shape that job-tracker.js expects.
 *
 * This is the only file in the project that knows about SDK field names.
 * When the plugin or the SDK changes, this is the file you fix.
 */

const GAMES = { 1: 'ETS2', 2: 'ATS' };

function n(v, fallback = 0) {
  return typeof v === 'number' && Number.isFinite(v) ? v : fallback;
}

function s(v, fallback = '') {
  return typeof v === 'string' ? v : fallback;
}

function firstTrailer(d) {
  const list = Array.isArray(d.TrailerValues) ? d.TrailerValues : [];
  return list[0] || null;
}

function trailerWear(t) {
  if (!t || !t.DamageValues) return 0;
  const dv = t.DamageValues;
  return Math.max(n(dv.Body), n(dv.Chassis), n(dv.Wheels));
}

/**
 * @param d    raw telemetry object
 * @param kind the recorder line kind: 'tick', 'JobDelivered', 'Fined', ...
 */
function toSnapshot(d, kind = 'tick') {
  const job = d.JobValues || {};
  const cargo = job.CargoValues || {};
  const truck = d.TruckValues || {};
  const consts = truck.ConstantsValues || {};
  const cur = truck.CurrentValues || {};
  const dash = cur.DashboardValues || {};
  const dmg = cur.DamageValues || {};
  const pos = (truck.Positioning || {}).HeadPositionInWorldSpace || {};
  const nav = d.NavigationValues || {};
  const spec = d.SpecialEventsValues || {};
  const gp = d.GamePlay || {};
  const trailer = firstTrailer(d);

  // The plugin clears JobValues the moment a job ends, so income of zero with
  // no destination means there is no live job, not a job worth nothing.
  const hasJob = !!spec.OnJob && !!s(job.CityDestinationId);

  return {
    connected: !!d.SdkActive,
    paused: !!d.Paused,
    game: GAMES[d.Game] || `unknown(${d.Game})`,
    gameVersion: `${n((d.GameVersion || {}).Major)}.${n((d.GameVersion || {}).Minor)}`,
    gameTimeMin: n((d.CommonValues || {}).GameTime && d.CommonValues.GameTime.Value),

    onJob: hasJob,
    job: hasJob
      ? {
          sourceCity: s(job.CitySource),
          sourceCityId: s(job.CitySourceId),
          sourceCompany: s(job.CompanySource),
          sourceCompanyId: s(job.CompanySourceId),
          destinationCity: s(job.CityDestination),
          destinationCityId: s(job.CityDestinationId),
          destinationCompany: s(job.CompanyDestination),
          destinationCompanyId: s(job.CompanyDestinationId),
          cargo: s(cargo.Name),
          cargoId: s(cargo.Id),
          cargoMassKg: n(cargo.Mass),
          income: n(job.Income),
          deadlineMin: n(job.DeliveryTime && job.DeliveryTime.Value),
          plannedDistanceKm: n(job.PlannedDistanceKm),
          specialJob: !!job.SpecialJob,
          market: n(job.Market),
        }
      : null,

    truck: {
      make: s(consts.Brand),
      model: s(consts.Name),
      odometerKm: n(dash.Odometer),
      speedKmh: n(dash.Speed && dash.Speed.Kph),
      fuelL: n(dash.FuelValue && dash.FuelValue.Amount),
      fuelCapacityL: n((consts.CapacityValues || {}).Fuel),
      wear: {
        engine: n(dmg.Engine),
        transmission: n(dmg.Transmission),
        cabin: n(dmg.Cabin),
        chassis: n(dmg.Chassis),
        wheels: n(dmg.WheelsAvg),
      },
    },

    trailer: {
      attached: !!(trailer && trailer.Attached),
      name: trailer ? s(trailer.Name) || s(trailer.Id) : '',
      wear: trailerWear(trailer),
      cargoDamage: trailer && trailer.DamageValues ? n(trailer.DamageValues.Cargo) : 0,
    },

    position: { x: n(pos.X), y: n(pos.Y), z: n(pos.Z) },
    speedLimitKmh: n(nav.SpeedLimit && nav.SpeedLimit.Kph),

    events: buildEvents(kind, gp),
  };
}

/**
 * The recorder writes an extra line whenever a gameplay event fires, tagged
 * with the event name. Only that line carries the event, which avoids the
 * classic bug of firing a delivery ten times because a flag stayed set.
 */
function buildEvents(kind, gp) {
  const e = {
    jobDelivered: null,
    jobCancelled: null,
    fined: null,
    tollgatePaid: null,
    ferryUsed: null,
    trainUsed: null,
    refuelPaid: null,
  };

  switch (kind) {
    case 'JobDelivered': {
      const j = gp.JobDelivered || {};
      e.jobDelivered = {
        revenue: n(j.Revenue),
        earnedXp: n(j.EarnedXp),
        cargoDamage: n(j.CargoDamage),
        distanceKm: n(j.DistanceKm),
        deliveryTimeMin: n(j.DeliveryTime && j.DeliveryTime.Value),
        autoparkUsed: !!j.AutoParked,
        autoLoaded: !!j.AutoLoaded,
        // Started is unreliable, the plugin author documents that it gets
        // overwritten. StartedBackup is the value to trust.
        startedGameMin: n(j.StartedBackup && j.StartedBackup.Value),
        finishedGameMin: n(j.Finished && j.Finished.Value),
      };
      break;
    }
    case 'JobCancelled': {
      const j = gp.JobCancelled || {};
      // Field name here is unverified, so accept the likely candidates.
      e.jobCancelled = {
        penalty: n(j.Penalty !== undefined ? j.Penalty : j.Fine),
        startedGameMin: n(j.StartedBackup && j.StartedBackup.Value),
        raw: j,
      };
      break;
    }
    case 'Fined': {
      const f = gp.FinedEvent || {};
      e.fined = { amount: n(f.Amount), offence: f.Offence };
      break;
    }
    case 'Tollgate': {
      const t = gp.TollgateEvent || {};
      e.tollgatePaid = { amount: n(t.PayAmount !== undefined ? t.PayAmount : t.Amount), raw: t };
      break;
    }
    case 'Ferry': {
      const f = gp.FerryEvent || {};
      e.ferryUsed = {
        source: s(f.SourceName),
        target: s(f.TargetName),
        price: n(f.PayAmount !== undefined ? f.PayAmount : f.Amount),
      };
      break;
    }
    case 'Train': {
      const t = gp.TrainEvent || {};
      e.trainUsed = {
        source: s(t.SourceName),
        target: s(t.TargetName),
        price: n(t.PayAmount !== undefined ? t.PayAmount : t.Amount),
      };
      break;
    }
    case 'RefuelPayed': {
      const r = gp.RefuelEvent || {};
      e.refuelPaid = { amount: n(r.Amount), raw: r };
      break;
    }
    default:
      break;
  }

  return e;
}

module.exports = { toSnapshot, buildEvents };
