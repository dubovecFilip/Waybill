'use strict';

/**
 * Live shipment tracker.
 *
 *   node live.js
 *
 * Watches the sessions folder TelemetryReader.exe writes into, tails
 * whichever .jsonl file is newest (following it as it grows, and switching
 * over automatically if the recorder gets restarted), and feeds every new
 * line through the same job tracker replay.js uses offline. Start this
 * before or after TelemetryReader.exe, in either order - it just waits for
 * a session file to show up.
 *
 * Every finished shipment is printed as it happens and appended to
 * shipments.jsonl next to this file, so the history survives even if
 * TelemetryReader's bin/ output gets wiped by a rebuild. Stop with Ctrl+C;
 * it prints a short summary of the run before exiting.
 */

const fs = require('fs');
const path = require('path');
const { JobTracker } = require('./job-tracker');
const { toSnapshot } = require('./adapter');
const { printJobStarted, printJobFinished } = require('./format');

const SESSIONS_DIR = path.join(__dirname, '..', 'TelemetryReader', 'bin', 'Debug', 'net9.0', 'sessions');
const SHIPMENTS_LOG = path.join(__dirname, 'shipments.jsonl');
const POLL_MS = 300;
const LOOK_FOR_NEWER_FILE_MS = 1000;

const stats = { accepted: 0, review: 0, rejected: 0 };
let shipmentCount = 0;

function findLatestSession() {
  if (!fs.existsSync(SESSIONS_DIR)) return null;
  const files = fs
    .readdirSync(SESSIONS_DIR)
    .filter((f) => f.endsWith('.jsonl'))
    .sort(); // "session-YYYYMMDD-HHMMSS.jsonl" sorts chronologically as text
  if (!files.length) return null;
  return path.join(SESSIONS_DIR, files[files.length - 1]);
}

// Minimal tail -f: poll the file size, read whatever bytes were appended
// since the last read, and split into complete lines. A line still being
// written (the recorder isn't done with WriteLine yet) is held in `buffer`
// until the rest of it shows up on the next poll.
function tailFile(filePath, onLine) {
  const fd = fs.openSync(filePath, 'r');
  let position = 0;
  let buffer = '';

  const timer = setInterval(() => {
    let size;
    try {
      size = fs.fstatSync(fd).size;
    } catch {
      return; // file got removed/rotated out from under us; next findLatestSession tick will recover
    }
    if (size <= position) return;

    const chunk = Buffer.alloc(size - position);
    fs.readSync(fd, chunk, 0, chunk.length, position);
    position = size;
    buffer += chunk.toString('utf8');

    let idx;
    while ((idx = buffer.indexOf('\n')) >= 0) {
      const line = buffer.slice(0, idx);
      buffer = buffer.slice(idx + 1);
      if (line.trim()) onLine(line);
    }
  }, POLL_MS);

  return () => {
    clearInterval(timer);
    fs.closeSync(fd);
  };
}

function logShipment(record) {
  fs.appendFileSync(SHIPMENTS_LOG, JSON.stringify(record) + '\n');
}

let tracker = new JobTracker();
let stopTailing = null;
let currentFile = null;

function switchTo(file) {
  if (stopTailing) stopTailing();
  currentFile = file;
  tracker = new JobTracker(); // a job cannot span two session files, start clean
  console.log(`\n[live] sledujem: ${path.basename(file)}`);
  stopTailing = tailFile(file, handleLine);
}

function handleLine(raw) {
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch {
    return; // a line caught mid-write; it'll be complete (and valid) on a later poll
  }

  const snap = toSnapshot(parsed.d, parsed.kind);
  const events = tracker.update(snap, parsed.t);

  for (const ev of events) {
    if (ev.type === 'job_started') printJobStarted(ev.job);

    if (ev.type === 'job_finished') {
      printJobFinished(ev.record);
      logShipment(ev.record);
      shipmentCount++;
      stats[ev.record.validation.status] = (stats[ev.record.validation.status] || 0) + 1;
    }
  }
}

console.log('[live] cakam na session subor v ' + SESSIONS_DIR);

const watchTimer = setInterval(() => {
  const latest = findLatestSession();
  if (latest && latest !== currentFile) switchTo(latest);
}, LOOK_FOR_NEWER_FILE_MS);

process.on('SIGINT', () => {
  clearInterval(watchTimer);
  if (stopTailing) stopTailing();
  console.log('\n\n================ KONIEC SLEDOVANIA ================');
  console.log(`zasielok spracovanych: ${shipmentCount}`);
  console.log(
    `   accepted: ${stats.accepted || 0}   review: ${stats.review || 0}   rejected: ${stats.rejected || 0}`
  );
  console.log(`log: ${SHIPMENTS_LOG}`);
  process.exit(0);
});
