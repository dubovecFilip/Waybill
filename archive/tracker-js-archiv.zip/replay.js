'use strict';

/**
 * Replays a recorded session file through the job tracker.
 *
 *   node replay.js path\to\session-20260811-174036.jsonl
 *
 * No game, no network, no database. Just a file and the state machine.
 * This is your regression test suite once you keep a few good recordings.
 */

const fs = require('fs');
const readline = require('readline');
const { JobTracker } = require('./job-tracker');
const { toSnapshot } = require('./adapter');
const { printJobStarted, printJobFinished } = require('./format');

const file = process.argv[2];
if (!file) {
  console.error('Pouzitie: node replay.js <subor.jsonl>');
  process.exit(1);
}

const tracker = new JobTracker();
const finished = [];
const anomalies = [];
let lines = 0;
let firstT = null;
let lastT = null;

const rl = readline.createInterface({
  input: fs.createReadStream(file),
  crlfDelay: Infinity,
});

rl.on('line', (raw) => {
  if (!raw.trim()) return;

  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch (err) {
    console.error(`Riadok ${lines + 1} sa neda rozparsovat, preskakujem.`);
    return;
  }

  lines++;
  if (firstT === null) firstT = parsed.t;
  lastT = parsed.t;

  const snap = toSnapshot(parsed.d, parsed.kind);
  const events = tracker.update(snap, parsed.t);

  for (const ev of events) {
    if (ev.type === 'job_started') printJobStarted(ev.job);

    if (ev.type === 'anomaly') {
      anomalies.push(ev);
    }

    if (ev.type === 'job_finished') {
      finished.push(ev.record);
      printJobFinished(ev.record);
    }
  }
});

rl.on('close', () => {
  const minutes = firstT && lastT ? ((lastT - firstT) / 60000).toFixed(1) : '0';
  console.log('\n================ SUHRN ================');
  console.log(`riadkov: ${lines}, realny cas nahravky: ${minutes} min`);
  console.log(`zakaziek: ${finished.length}`);
  console.log(`anomalii pocas jazdy: ${anomalies.length}`);

  const byCode = {};
  for (const a of anomalies) byCode[a.code] = (byCode[a.code] || 0) + 1;
  for (const [code, count] of Object.entries(byCode)) {
    console.log(`   ${code}: ${count}x`);
  }

  if (!finished.length) {
    console.log('\nZiadna zakazka sa neuzavrela. Ak si v hre dorucil, nieco je zle v detekcii.');
  }
});
